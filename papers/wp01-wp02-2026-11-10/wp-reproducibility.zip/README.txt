WP-01 / WP-02, web revision 2026-11-10. Original manuscript date: 2026-09-11.
Requirements: Python 3, numpy, openpyxl.
Run: python verify_numbers.py research-sources
The program reads the archived source files and writes verification results beside itself.
No network access is needed. Original source directories are not modified.
Annual price observations use Q1-Q2. Supplementary mortgage window ends in August 2026.
Matrix revisions change the coding of September evidence, not the observation date.
Source scripts fe_panel.py and counts_check.py are preserved as historical inputs; verify_numbers.py fits the two sets of effects jointly for the revised result.
